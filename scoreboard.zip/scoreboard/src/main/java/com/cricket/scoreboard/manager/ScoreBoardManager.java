package com.cricket.scoreboard.manager;

import com.cricket.scoreboard.model.Ball;
import com.cricket.scoreboard.model.Match;
import com.cricket.scoreboard.model.Over;
import com.cricket.scoreboard.model.Player;
import com.cricket.scoreboard.model.Team;
import com.cricket.scoreboard.utils.BallType;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Objects;

public class ScoreBoardManager {

    private final TeamManager teamManager;

    private final PlayerManager playerManager;

    private final MatchManager matchManager;

    @Getter
    @Setter
    private Match match;

    public ScoreBoardManager(TeamManager teamManager, PlayerManager playerManager,MatchManager matchManager) {
        this.teamManager = teamManager;
        this.playerManager = playerManager;
        this.matchManager = matchManager;
    }

    public void startSecondInning() {
        Team team = match.getBattingTeam();
        match.setBattingTeam(match.getBowlingTeam());
        match.setBowlingTeam(team);
        match.setStriker(match.getBattingTeam().getListOfPlayer().get(0));
        match.setNonSticker(match.getBattingTeam().getListOfPlayer().get(1));
    }

    public void updateOnOver(String bowler, List<String> listOfBallesInOver) {
        Over over = new Over();
        Player player1 = teamManager.getPlayerByNameInTeam(match.getBowlingTeam(), bowler);
        if (Objects.nonNull(player1)) {
            playerManager.updateOverBowled(player1, over);
        }
        for (String ball : listOfBallesInOver) {
            Ball ball1;
            switch (ball) {
                case "W":
                    ball1 = new Ball(BallType.W, 0);
                    playerManager.updateOnPlayedBall(this.getMatch().getStriker(), ball1);
                    matchManager.getNewPlayerIn(getMatch());
                    break;
                case "WD":
                    ball1 = new Ball(BallType.WD, 1);
                    playerManager.updateOnPlayedBall(this.getMatch().getStriker(), ball1);
                    break;
                case "ND":
                    ball1 = new Ball(BallType.ND, 1);
                    playerManager.updateOnPlayedBall(this.getMatch().getStriker(), ball1);
                    break;
                default:
                    ball1 = new Ball(BallType.RN, Integer.parseInt(ball));
                    playerManager.updateOnPlayedBall(this.getMatch().getStriker(), ball1);
                    matchManager.changeStrike(getMatch(),ball1);
                    break;
            }
            over.getBallList().add(ball1);
        }
        matchManager.changeStrike(getMatch(),null);

    }

    public void startMatch(Integer noOfPlayerEachTeam, Integer noOfOvers, String t1Name, String t2Name, List<String> t1PlayerList, List<String> t2PlayerList) {
        Team team1 = new Team(t1Name);
        Team team2 = new Team(t2Name);
        // adding team1 player
        for (String player : t1PlayerList) {
            Player player1 = new Player(player);
            teamManager.addPlayer(team1, player1);
        }
        //adding team2 player
        for (String player : t2PlayerList) {
            Player player2 = new Player(player);
            teamManager.addPlayer(team2, player2);
        }
        //initially we will assume team1 as batting team team2 as bowling team;
        setMatch(new Match(noOfPlayerEachTeam, noOfOvers));
        match.setBattingTeam(team1);
        match.setBowlingTeam(team2);
        // default setting 1st and 2nd player as striker;
        match.setStriker(team1.getListOfPlayer().get(0));
        match.setNonSticker(team1.getListOfPlayer().get(1));
    }

    public Team getWinningTeam() {
        return (teamManager.getRunScored(match.getBattingTeam(),match.getBowlingTeam()) > teamManager.getRunScored(match.getBowlingTeam(),match.getBattingTeam()) ? match.getBattingTeam() : match.getBowlingTeam());
    }

}
