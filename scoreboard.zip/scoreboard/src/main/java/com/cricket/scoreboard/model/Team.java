package com.cricket.scoreboard.model;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
public class Team {
    private final String teamName;
    @Setter
    private List<Player> listOfPlayer;

    public Team(String teamName) {
        this.teamName = teamName;
        this.listOfPlayer = new ArrayList<>();
    }
}
