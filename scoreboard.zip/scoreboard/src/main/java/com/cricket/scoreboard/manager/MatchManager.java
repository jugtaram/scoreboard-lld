package com.cricket.scoreboard.manager;

import com.cricket.scoreboard.model.Ball;
import com.cricket.scoreboard.model.Match;
import com.cricket.scoreboard.model.Player;

public class MatchManager {

    private final TeamManager teamManager;

    public MatchManager(TeamManager teamManager) {
        this.teamManager = teamManager;
    }

    public void changeStrike(Match match, Ball ball) {
        if (ball == null) {
            Player player = match.getStriker();
            match.setStriker(match.getNonSticker());
            match.setNonSticker(player);
        } else if (ball.getRunScored() % 2 == 1) {
            Player player = match.getStriker();
            match.setStriker(match.getNonSticker());
            match.setNonSticker(player);

        }
    }

    public void getNewPlayerIn(Match match) {
        int wicketFallen = teamManager.getWicketFallen(match.getBattingTeam());
        if (wicketFallen + 1 >= match.getNoOfPlayerEachTeam()) {
            System.out.println("\n TEAM All OUt");
            return;
        }
        Player player = teamManager.getNextPlayerIn(match.getBattingTeam());
        // we will make new player at striker end defaul;
        match.setStriker(player);
    }
}
