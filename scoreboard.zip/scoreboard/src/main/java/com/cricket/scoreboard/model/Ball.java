package com.cricket.scoreboard.model;

import com.cricket.scoreboard.utils.BallType;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class Ball {
    private BallType ballType;
    private Integer runScored=0;
}
