package com.cricket.scoreboard.model;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;

@Getter
public class Player extends Score {
    private final String name;

    public Player(String name) {
        this.name = name;
        this.ballPlayed = new ArrayList<>();
        this.overBowled = new ArrayList<>();
    }
}
