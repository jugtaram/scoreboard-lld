package com.cricket.scoreboard.manager;

import com.cricket.scoreboard.model.Player;
import com.cricket.scoreboard.model.Team;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

public class TeamManager {

    private  final PlayerManager playerManager;

    public TeamManager(PlayerManager playerManager) {
        this.playerManager = playerManager;
    }

    public int getRunScored(Team battingteam, Team bowlingTeam) {
        int totalScore = 0;
        for (Player player : battingteam.getListOfPlayer()) {
            totalScore += playerManager.getRunScored(player);
        }
        totalScore += getExtraRunGiven(bowlingTeam);
        return totalScore;
    }

    public Player getPlayerByNameInTeam(Team team, String name) {
        for (Player player : team.getListOfPlayer()) {
            if (player.getName().equals(name)) return player;
        }
        return null;
    }

    public int getWicketFallen(Team team) {
        return (int) team.getListOfPlayer().stream().filter(player -> playerManager.isPlayerOut(player)).count();
    }

    public Player getNextPlayerIn(Team team) {
        return team.getListOfPlayer().get(getWicketFallen(team)+1);
    }

    public int getOverBowled( Team team) {
        int overBowled = 0;
        List<Player> playerList = team.getListOfPlayer();
        for (Player player : playerList) {
            overBowled += player.getOverBowled().size();
        }
        return overBowled;
    }

    public int getExtraRunGiven(Team team) {
        int extraRun = 0;
        for (Player player : team.getListOfPlayer()) {
            extraRun += playerManager.getExtraRunGiven(player);
        }
        return extraRun;
    }

    public void addPlayer(Team team,Player player) {
        team.getListOfPlayer().add(player);
    }

}
