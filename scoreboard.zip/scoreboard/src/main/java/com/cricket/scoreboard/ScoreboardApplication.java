package com.cricket.scoreboard;

import com.cricket.scoreboard.manager.PlayerManager;
import com.cricket.scoreboard.manager.ScoreBoardManager;
import com.cricket.scoreboard.manager.TeamManager;
import com.cricket.scoreboard.model.Match;
import com.cricket.scoreboard.model.Player;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class ScoreboardApplication {

	public static void main(String[] args) {

		PlayerManager playerManager = new PlayerManager();
		TeamManager teamManager = new TeamManager(playerManager);
		ScoreBoardManager scoreBoardManager= new ScoreBoardManager(teamManager,playerManager,null);
		// starting match:
		System.out.println("\nINPUT \n NUMBER OF PLAYER IN EACH TEAM: 5 \n NUMBER OF OVERS: 2 \n TEAM 1 NAME: T1 \n TEAM 2 NAME: T2 \n LIST OF TEAM 1 PLAYER: [P1,P2,P3,P4,P5] \n LIST OF TEAM 2 PLAYER: [P6,P7,P8,P8,P9,P10]\n ");
		List<String> t1Player = new ArrayList<>();
		t1Player.add("P1");t1Player.add("P2");t1Player.add("P3");t1Player.add("P4");t1Player.add("P5");
		List<String> t2Player = new ArrayList<>();
		t2Player.add("P6");t2Player.add("P7");t2Player.add("P8");t2Player.add("P9");t2Player.add("P10");
		//assuming this is batting order of team player
		scoreBoardManager.startMatch(5,2,"T1","T2",t1Player,t2Player);

		//start play for team 1:
		//OVER 1
		System.out.println("\nINPUT \n BOWLER NAME: P6  \n OVER BALLS: [1, 1, 1, 1, 1, 2] ");
		List<String> overBall = new ArrayList<>();
		overBall.add("1");overBall.add("1");overBall.add("1");overBall.add("1");overBall.add("1");overBall.add("2");
		scoreBoardManager.updateOnOver("P6",overBall);

		// -- START SHOW SCORE BOARD --
		System.out.println("\nTEAM 1: OVERVIEW");
		System.out.println("\n TOTAL SCORE: "+ teamManager.getRunScored(scoreBoardManager.getMatch().getBattingTeam(),scoreBoardManager.getMatch().getBowlingTeam())+
				"\n TOTAL WICKET FALL: "+teamManager.getWicketFallen(scoreBoardManager.getMatch().getBattingTeam())+
				" \n TOTAL OVER: "+ teamManager.getOverBowled(scoreBoardManager.getMatch().getBowlingTeam()));

		System.out.println("\n PLAYER WISE BATTING DETAILS: ");
		for (Player player: scoreBoardManager.getMatch().getBattingTeam().getListOfPlayer()) {
			System.out.println("\n PLAYER: "+player.getName()+"\tBALL PLAYED: " + playerManager.getBowlPlayed(player) + "\t RUN  SCORED: " + playerManager.getRunScored(player) +
					"\t NUMBER OF 4s: " + playerManager.getNumberOfFour(player) + "\t NUMBER OF 6s: " + playerManager.getNumberOfSixes(player) +"\t STRIKE RATE: "+ playerManager.getStrikeRate(player));
		}
		System.out.println("\n PLAYER WISE BOWLING DETAILS: ");
		for (Player player: scoreBoardManager.getMatch().getBowlingTeam().getListOfPlayer()) {
			System.out.println("\n PLAYER: "+player.getName()+"\tOVER BOWLED: " + playerManager.getOverBowled(player) + "\t WICKET TAKEN: " + playerManager.getWicketTaken(player) +
					"\t ECONOMY: " + playerManager.getBowlingEconomy(player) + "\t DOT BALLS: " + playerManager.getNumberOfDotBalls(player));
		}
		// -- END SHOW SCORE BOARD --

		//OVER 2
		System.out.println("\nINPUT \n BOWLER NAME: P7  \n OVER BALLS: [W, 4, 4, WD, W, 1, 6] ");
		List<String> overBall1 = new ArrayList<>();
		overBall1.add("W");overBall1.add("4");overBall1.add("4");overBall1.add("WD");overBall1.add("W");overBall1.add("1");overBall1.add("6");
		scoreBoardManager.updateOnOver("P7",overBall1);

		// -- START SHOW SCORE BOARD --
		System.out.println("\nTEAM 1: OVERVIEW");
		System.out.println("\n TOTAL SCORE: "+ teamManager.getRunScored(scoreBoardManager.getMatch().getBattingTeam(),scoreBoardManager.getMatch().getBowlingTeam())+
				"\n TOTAL WICKET FALL: "+teamManager.getWicketFallen(scoreBoardManager.getMatch().getBattingTeam())+
				" \n TOTAL OVER: "+ teamManager.getOverBowled(scoreBoardManager.getMatch().getBowlingTeam()));

		System.out.println("\n PLAYER WISE BATTING DETAILS: ");
		for (Player player: scoreBoardManager.getMatch().getBattingTeam().getListOfPlayer()) {
			System.out.println("\n PLAYER: "+player.getName()+"\tBALL PLAYED: " + playerManager.getBowlPlayed(player) + "\t RUN  SCORED: " + playerManager.getRunScored(player) +
					"\t NUMBER OF 4s: " + playerManager.getNumberOfFour(player) + "\t NUMBER OF 6s: " + playerManager.getNumberOfSixes(player) +"\t STRIKE RATE: "+ playerManager.getStrikeRate(player));
		}
		System.out.println("\n PLAYER WISE BOWLING DETAILS: ");
		for (Player player: scoreBoardManager.getMatch().getBowlingTeam().getListOfPlayer()) {
			System.out.println("\n PLAYER: "+player.getName()+"\tOVER BOWLED: " + playerManager.getOverBowled(player) + "\t WICKET TAKEN: " + playerManager.getWicketTaken(player) +
					"\t ECONOMY: " + playerManager.getBowlingEconomy(player) + "\t DOT BALLS: " + playerManager.getNumberOfDotBalls(player));
		}
		// -- END SHOW SCORE BOARD --



		//start play for team 2:
		scoreBoardManager.startSecondInning();
		//OVER 1
		System.out.println("\nINPUT \n BOWLER NAME: P4  \n OVER BALLS: [4, 6, W, W, 1, 1] ");
		List<String> overBall2 = new ArrayList<>();
		overBall2.add("4");overBall2.add("6");overBall2.add("W");overBall2.add("W");overBall2.add("1");overBall2.add("1");
		scoreBoardManager.updateOnOver("P4",overBall2);

		// -- START SHOW SCORE BOARD --
		System.out.println("\nTEAM 2: OVERVIEW");
		System.out.println("\n TOTAL SCORE: "+ teamManager.getRunScored(scoreBoardManager.getMatch().getBattingTeam(),scoreBoardManager.getMatch().getBowlingTeam())+
				"\n TOTAL WICKET FALL: "+teamManager.getWicketFallen(scoreBoardManager.getMatch().getBattingTeam())+
				" \n TOTAL OVER: "+ teamManager.getOverBowled(scoreBoardManager.getMatch().getBowlingTeam()));

		System.out.println("\n PLAYER WISE BATTING DETAILS: ");
		for (Player player: scoreBoardManager.getMatch().getBattingTeam().getListOfPlayer()) {
			System.out.println("\n PLAYER: "+player.getName()+"\tBALL PLAYED: " + playerManager.getBowlPlayed(player) + "\t RUN  SCORED: " + playerManager.getRunScored(player) +
					"\t NUMBER OF 4s: " + playerManager.getNumberOfFour(player) + "\t NUMBER OF 6s: " + playerManager.getNumberOfSixes(player) +"\t STRIKE RATE: "+ playerManager.getStrikeRate(player));
		}
		System.out.println("\n PLAYER WISE BOWLING DETAILS: ");
		for (Player player: scoreBoardManager.getMatch().getBowlingTeam().getListOfPlayer()) {
			System.out.println("\n PLAYER: "+player.getName()+"\tOVER BOWLED: " + playerManager.getOverBowled(player) + "\t WICKET TAKEN: " + playerManager.getWicketTaken(player) +
					"\t ECONOMY: " + playerManager.getBowlingEconomy(player) + "\t DOT BALLS: " + playerManager.getNumberOfDotBalls(player));
		}
		// -- END SHOW SCORE BOARD --

		//OVER 2
		System.out.println("\nINPUT \n BOWLER NAME: P5  \n OVER BALLS: [6, 1, W, W] ");
		List<String> overBall3 = new ArrayList<>();
		overBall3.add("6");overBall3.add("1");overBall3.add("W");overBall3.add("W");
		scoreBoardManager.updateOnOver("P5",overBall3);

		// -- START SHOW SCORE BOARD --
		System.out.println("\nTEAM 2: OVERVIEW");
		System.out.println("\n TOTAL SCORE: "+ teamManager.getRunScored(scoreBoardManager.getMatch().getBattingTeam(),scoreBoardManager.getMatch().getBowlingTeam())+
				"\n TOTAL WICKET FALL: "+teamManager.getWicketFallen(scoreBoardManager.getMatch().getBattingTeam())+
				" \n TOTAL OVER: "+ teamManager.getOverBowled(scoreBoardManager.getMatch().getBowlingTeam()));

		System.out.println("\n PLAYER WISE BATTING DETAILS: ");
		for (Player player: scoreBoardManager.getMatch().getBattingTeam().getListOfPlayer()) {
			System.out.println("\n PLAYER: "+player.getName()+"\tBALL PLAYED: " + playerManager.getBowlPlayed(player) + "\t RUN  SCORED: " + playerManager.getRunScored(player) +
					"\t NUMBER OF 4s: " + playerManager.getNumberOfFour(player) + "\t NUMBER OF 6s: " + playerManager.getNumberOfSixes(player) +"\t STRIKE RATE: "+ playerManager.getStrikeRate(player));
		}
		System.out.println("\n PLAYER WISE BOWLING DETAILS: ");
		for (Player player: scoreBoardManager.getMatch().getBowlingTeam().getListOfPlayer()) {
			System.out.println("\n PLAYER: "+player.getName()+"\tOVER BOWLED: " + playerManager.getOverBowled(player) + "\t WICKET TAKEN: " + playerManager.getWicketTaken(player) +
					"\t ECONOMY: " + playerManager.getBowlingEconomy(player) + "\t DOT BALLS: " + playerManager.getNumberOfDotBalls(player));
		}
		// -- END SHOW SCORE BOARD --

		//RESULT:
		String winner = scoreBoardManager.getWinningTeam().getTeamName().toUpperCase();
		if(winner.equals("T1")) {
			System.out.println("\nAS PER SCORE CARD WINNER IS T1");
		}else {
			System.out.println("\nAS PER SCORE CARD WINNER IS T2");
		}
		SpringApplication.run(ScoreboardApplication.class, args);
	}

}
