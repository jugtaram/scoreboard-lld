package com.cricket.scoreboard.manager;

import com.cricket.scoreboard.model.Ball;
import com.cricket.scoreboard.model.Over;
import com.cricket.scoreboard.model.Player;
import com.cricket.scoreboard.utils.BallType;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class PlayerManager {


    public int getRunScored(Player player) {
        int runScored = 0;
        List<Ball> playedBallList = player.getBallPlayed();
        for (Ball ball : playedBallList) {
            if (BallType.RN.equals(ball.getBallType())) {
                runScored += ball.getRunScored();
            }
        }
        return runScored;
    }

    public int getBowlPlayed(Player player) {
        int ballPlayed = 0;
        for (Ball ball : player.getBallPlayed()) {
            ballPlayed += ((BallType.W.equals(ball.getBallType()) || BallType.RN.equals(ball.getBallType())) ? 1 : 0);
        } return ballPlayed;
    }

    public int getOverBowled(Player player) {
        return player.getOverBowled().size();
    }

    public void updateOverBowled(Player player, Over over) {
        player.getOverBowled().add(over);
    }

    public void updateOnPlayedBall(Player player, Ball ball) {
        player.getBallPlayed().add(ball);
    }

    public int getWicketTaken(Player player) {
        int wicket = 0;
        List<Over> overList = player.getOverBowled();
        for (Over over : overList) {
            wicket += (int) over.getBallList().stream().filter(ball -> BallType.W.equals(ball.getBallType())).count();
        }
        return wicket;
    }

    public int getExtraRunGiven(Player player) {
        int extraRunGiven = 0;
        List<Over> overList = player.getOverBowled();
        for (Over over : overList) {
            extraRunGiven += (int) over.getBallList().stream().filter(ball -> (BallType.ND.equals(ball.getBallType()) || BallType.WD.equals(ball.getBallType()))).count();
        }
        return extraRunGiven;
    }

    public boolean isPlayerOut(Player player) {
        List<Ball> playedBallList = player.getBallPlayed();
        for (Ball ball : playedBallList) {
            if (BallType.W.equals(ball.getBallType())) {
                return true;
            }
        }
        return false;
    }
    public int getNumberOfSixes(Player player){
        int countOf6 =0;
        List<Ball> ballList = player.getBallPlayed();
        for (Ball ball : ballList) {
            countOf6 +=  ((BallType.RN.equals(ball.getBallType()) && 6==ball.getRunScored())?1:0);
        }
        return countOf6;
    }

    public int getNumberOfFour(Player player){
        int countOf4 =0;
        List<Ball> ballList = player.getBallPlayed();
        for (Ball ball : ballList) {
            countOf4 +=  ((BallType.RN.equals(ball.getBallType()) && 4==ball.getRunScored())?1:0);
        }
        return countOf4;
    }

    public int getNumberOfDotBalls(Player player){
        int countOf4 =0;
        List<Over> overList = player.getOverBowled();
        for (Over over : overList) {
            countOf4 += (int) over.getBallList().stream().filter(ball -> (BallType.RN.equals(ball.getBallType()) && 0==ball.getRunScored())).count();
        }
        return countOf4;
    }

    public int getTotalRunGiven(Player player) {
        int totalRunGiven = 0;
        List<Over> overList = player.getOverBowled();
        List<Ball> ballList = new ArrayList<>();
        for (Over over : overList) {
            ballList.addAll(over.getBallList().stream().filter(ball -> (!BallType.W.equals(ball.getBallType()))).collect(Collectors.toList()));
        }
        for (Ball ball : ballList) {
            totalRunGiven += ball.getRunScored();
        }
        return totalRunGiven;
    }

    public int getStrikeRate(Player player) {
        if (getBowlPlayed(player) > 0) {
            return (getRunScored(player) / getBowlPlayed(player));
        }
        return 0;
    }

    public int getBowlingEconomy(Player player) {
        if (getOverBowled(player) > 0) {
            return getTotalRunGiven(player) / getOverBowled(player);
        }
        return 0;
    }


}
