package com.cricket.scoreboard.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
public class Score {

    @Setter
    protected List<Ball> ballPlayed;
    @Setter
    protected List<Over> overBowled;
}
