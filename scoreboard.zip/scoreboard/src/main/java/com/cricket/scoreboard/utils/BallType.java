package com.cricket.scoreboard.utils;

public enum BallType {
    ND,  // nd -> no ball, wd -> wide ball, w -> wicket, RN -> Run taken
    WD,
    W,
    RN
}
