package com.cricket.scoreboard.model;

import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

@Getter
public class Over {
    List<Ball> ballList = new ArrayList<>();
}
