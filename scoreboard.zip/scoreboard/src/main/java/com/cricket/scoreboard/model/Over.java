package com.cricket.scoreboard.model;

import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

@Getter
public class Over {
    // we can make Ball model also but just only one field so keeping it normal string.
    List<Ball> ballList = new ArrayList<>();
}
