package com.cricket.scoreboard.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
public class Match {
    private final Integer noOfPlayerEachTeam;
    private final Integer noOfOvers;
    public Match(Integer noOfPlayerEachTeam, Integer noOfOvers) {
        this.noOfPlayerEachTeam = noOfPlayerEachTeam;
        this.noOfOvers = noOfOvers;
    }

    @Setter
    private Player striker;
    @Setter
    private Player nonSticker;

    @Setter
    private Team battingTeam;
    @Setter
    private Team bowlingTeam;
}
